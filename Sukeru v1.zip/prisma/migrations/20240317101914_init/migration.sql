-- AlterTable
ALTER TABLE "User" ADD COLUMN     "lastUpdated" TEXT,
ALTER COLUMN "lastMessage" SET DATA TYPE TEXT;
