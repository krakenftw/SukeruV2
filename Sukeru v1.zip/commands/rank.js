const { SlashCommandBuilder, hyperlink, hideLinkEmbed } = require("discord.js");
const client = require("../lib/db");
const { createUserDb } = require("../lib/user");
const { EmbedBuilder } = require("discord.js");
const { DateTime } = require("luxon");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("rank")
        .setDescription("Get your rank info!"),
    async execute(interaction) {
        const member = await interaction.guild.members.cache.get(interaction.user.id)

        const user = await client.user.findFirst({ where: { userId: interaction.user.id } });
        if (!user) {
            createUserDb(interaction.user.id);
        }
        const usersData = await client.user.findMany({
            orderBy: {
                xp: 'desc'
            }
        })
        try{
        const userIndex = usersData.findIndex(u => u.id === user.id) + 1;

        const createdTime = interaction.user.createdAt;
        const joinedTime = DateTime.fromJSDate(user.joined)
        const date = DateTime.fromJSDate(createdTime)
        const firstMessage = `https://discord.com/channels/${interaction.guild.id}/${process.env.FIRST_MESSSAGE_CHANNEL}/${user.joinMessage}`;
        const secondMessage = `https://discord.com/channels/${interaction.guild.id}/${process.env.SECOND_MESSAGE_CHANNEL}/${user.joinMessageTwo}`;
        console.log(secondMessage)
        const embed = new EmbedBuilder().setColor(15418782).setTitle(`${interaction.user.username} Rank Info`).setColor(2303786).setDescription(`↪ User: <@${interaction.user.id}>\n↪ Rank In Server: **${userIndex}**\n↪ Level: **${user.level}**\n↪ status: **${member.presence.status}**\n↪ Created At: ${date.toLocaleString()}\n↪ Joined Server: ${joinedTime.toLocaleString()}\n↪ ${hyperlink("First Message", firstMessage)} \n↪ ${secondMessage ? hyperlink("Second Message", secondMessage) : ""}`).setTimestamp();

        interaction.reply({ embeds: [embed] })
        }catch(err){
            console.log(err)
        }

    },
}
