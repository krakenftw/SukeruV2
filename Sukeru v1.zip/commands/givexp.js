const { SlashCommandBuilder } = require("discord.js");
const client = require("../lib/db");
const { createUserDb, getLevel } = require("../lib/user");
const { EmbedBuilder } = require("discord.js");
const { DateTime } = require("luxon");
const { PermissionFlagsBits } = require("discord.js");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("givexp")
        .setDescription("Give XP to user!")
        .addUserOption(option =>
            option.setName('user')
                .setDescription('The user to give XP to')
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('amount')
                .setDescription('The amount of XP to give')
                .setRequired(true)),
    async execute(interaction) {
        const user = interaction.options.getUser('user');
        const amount = interaction.options.getInteger('amount');

        try {
            let targetUser = await client.user.findFirst({ where: { userId: user.id } });

            if (!targetUser) {
                targetUser = await createUserDb(user.id);
            }

            const updatedXP = targetUser.xp + amount;
            const updatedLevel = getLevel(updatedXP);

            await client.user.update({
                where: { id: targetUser.id },
                data: {
                    xp: updatedXP,
                    level: updatedLevel
                }
            });

            const embed = new EmbedBuilder()
                .setTitle("XP Given Successfully")
                .setDescription(`Successfully gave ${amount} XP to ${user.toString()}!`)
                .setColor("#00ff00")
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
        } catch (error) {
            console.error(error);
            await interaction.reply("An error occurred while giving XP.");
        }
    }
};
