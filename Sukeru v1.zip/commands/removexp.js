const { SlashCommandBuilder } = require("discord.js");
const client = require("../lib/db");
const { EmbedBuilder } = require("discord.js");
const { PermissionFlagsBits } = require("discord.js");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("removexp")
        .setDescription("Remove XP from a user!")
        .addUserOption(option => option.setName('user').setDescription('The user to remove XP from').setRequired(true))
        .addIntegerOption(option => option.setName('amount').setDescription('The amount of XP to remove').setRequired(true)),
    async execute(interaction) {
        const user = interaction.options.getUser('user');
        const amount = interaction.options.getInteger('amount');

        try {
            const userData = await client.user.findFirst({ where: { userId: user.id } });
            if (!userData) {
                return await interaction.reply("User data not found.");
            }

            if (userData.xp < amount) {
                return await interaction.reply("User does not have enough XP to remove.");
            }

            await client.user.update({
                where: { id: userData.id },
                data: { xp: userData.xp - amount }
            });

            const embed = new EmbedBuilder()
                .setTitle(`${user.username} XP Removed`)
                .setColor("#ff0000")
                .setDescription(`Removed ${amount} XP from <@${user.id}>`)
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
        } catch (error) {
            console.error(error);
            await interaction.reply("An error occurred while removing XP.");
        }
    },
};
