-- AlterTable
ALTER TABLE "User" ADD COLUMN     "joinMessageTwo" TEXT;
