-- AlterTable
ALTER TABLE "ChannelXP" ADD COLUMN     "earnxp" BOOLEAN;
