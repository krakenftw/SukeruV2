-- AlterTable
ALTER TABLE "User" ADD COLUMN     "joinMessage" TEXT;
